<section class="call">
    <div class="container">
        <div class="call_title">Вызовите замерщика<br>на дом БЕСПЛАТНО!</div>
        <div class="call_subtittle">Мы приедем к вам домой, вместе с вами снимем замеры<br>
            и разработаем дизайн-проект кухни вашей мечты!
        </div>
        <form class="call_form" id="call-form">
            <input class="call_form_input" name="callname" type="text" placeholder="Ваше имя">
            <input class="call_form_input" name="callphone" type="tel" placeholder="+7(      ) _____ - ___ - ___">
            <input class="call_form_input" name="calldate" type="datetime" placeholder="Дата и время">
            <button class="installment_btn call_form_btn" id="call-btn">Вызвать замерщика</button>           
        </form>
    </div>
    <!-- <form class="call-order_form" id="call-order-form">
            <div class="request_form_title">Заказать замерщика
                <div class="request_form_close" id="call-order-close">X</div>
            </div>
            <div class="request_form_subtitle">Оставьте заявку и наш менеджер свяжется с Вами</div>
            <div class="request_form_wrapper">
                <input class="request_form_input" name="callname" type="text" placeholder="Ваше имя">
                <input class="request_form_input" name="callphone" type="tel" placeholder="+7(      ) _____ - ___ - ___">
                <button class="request_form_btn" id="call-form-btn">Вызвать замерщика</button>
                <div class="request_form_info">Нажимая на кнопку вы соглашаетесь с Персональной обработкой данных</div>
            </div>								
        </form> -->
</section>