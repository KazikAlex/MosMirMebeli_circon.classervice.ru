<?php get_header(); ?>

<div class="container">
    <div class="page404">
    
        <!-- <div class="page404-img"></div> -->
        <div class="page404-header">Ошибка 404</div>
        <div class="page404-subheader">Такой страницы больше нет, попробуйте поискать в <span>каталоге</span> или </div>
        <div class="page404-link"><a href="<?php echo home_url(); ?>">На главную</a></div>
    </div>
</div>


<?php get_footer();?>
