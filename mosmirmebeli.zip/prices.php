<?php
/*
 * Template Name: Цены
*/
?>

<?php get_header(); ?>

<div class="container">
    <br><br> <div class="breadcrumb"><?php the_breadcrumb() ?></div><br><br>
</div>  

<?php get_template_part( 'product' ); ?>

<?php get_footer();?>